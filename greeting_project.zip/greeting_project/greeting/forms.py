from django import forms

class NameForm(forms.Form):
    name = forms.CharField(
        label='Ваше имя:',
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={
            'placeholder': 'Введите ваше имя здесь',
            'class': 'name-input'
        }),
        error_messages={
            'required':'Пожалуйста, введите Ваше имя!'
        }
    )