from django.shortcuts import render, redirect
from .forms import NameForm
from .models import UserName


def home(request):
    # Получаем все имена из базы данных
    all_names = UserName.objects.all()

    # Если пользователь отправил форму
    if request.method == 'POST':
        form = NameForm(request.POST)

        if form.is_valid():
            name = form.cleaned_data['name']

            clean_name = name.strip() if name else ''
            if not clean_name:
                form.add_error('name', 'Пожалуйста, введите Ваше имя!')
            else:
                UserName.objects.create(name=clean_name)
                all_names = UserName.objects.all()

                # Показываем страницу с новым именем
                return render(request, 'home.html', {
                    'form': NameForm(),
                    'all_names': all_names,
                    'last_name': clean_name
                })
    else:
        form = NameForm()

    # Показываем обычную страницу
    last_name = all_names.last().name if all_names.exists() else None
    return render(request, 'home.html', {
        'form': form,
        'all_names': all_names,
        'last_name': last_name
    })