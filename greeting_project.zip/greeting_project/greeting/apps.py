from django.apps import AppConfig


class GreetingConfig(AppConfig):
    name = 'greeting'
